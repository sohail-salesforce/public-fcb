# Summary of Current Issue

## Problem
The DataWeave script for extracting CPU and Memory peak values has a scope issue with the `$` implicit parameter in nested lambda functions.

### Error Messages:
```
Unable to resolve reference of: `$`. at 1 : 289
Unable to resolve reference of: `$`. at 1 : 936
```

### Current Code (Line 136):
```dataweave
var allCpuData = flatten(payload.workerStatistics map (($.statistics.cpu default {}) pluck {value: $, timestamp: $$}))
```

### Issue:
When using nested `map` and `pluck` with implicit `$` parameters, DataWeave cannot resolve which `$` refers to which lambda scope.

### Solution:
Use explicit parameter names for all lambda functions:
```dataweave
var allCpuData = flatten(payload.workerStatistics map (worker) -> 
    (worker.statistics.cpu default {}) pluck (value, key) -> {value: value, timestamp: key}
)
```

## Next Steps:
1. Stop current Mule app
2. Fix the DataWeave expressions with explicit lambda parameters
3. Test the application

## Current Status:
- XML structure is valid ✅
- Application is deployed but DataWeave has runtime errors ❌
- Need to fix lambda scope issues in stats extraction







