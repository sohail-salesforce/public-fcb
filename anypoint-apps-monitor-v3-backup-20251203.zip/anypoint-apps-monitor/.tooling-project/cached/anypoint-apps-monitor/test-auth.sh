#!/bin/bash

# Test Anypoint Platform OAuth2 Authentication

# Read credentials from config.properties
CLIENT_ID="916dc3b00ea44c31824b3b2f75bddcaa"
CLIENT_SECRET="507F0267D20f472aAFfAf70Bd2679982"

echo "========================================="
echo "Testing Anypoint Platform Authentication"
echo "========================================="
echo ""

# Step 1: Get OAuth2 Token
echo "Step 1: Getting OAuth2 token..."
TOKEN_RESPONSE=$(curl -s -X POST https://anypoint.mulesoft.com/accounts/api/v2/oauth2/token \
  -H "Content-Type: application/json" \
  -d "{
    \"client_id\": \"$CLIENT_ID\",
    \"client_secret\": \"$CLIENT_SECRET\",
    \"grant_type\": \"client_credentials\"
  }")

echo "Token Response:"
echo "$TOKEN_RESPONSE" | jq .
echo ""

# Extract access token
ACCESS_TOKEN=$(echo "$TOKEN_RESPONSE" | jq -r '.access_token')

if [ "$ACCESS_TOKEN" == "null" ] || [ -z "$ACCESS_TOKEN" ]; then
  echo "ERROR: Failed to get access token!"
  exit 1
fi

echo "Access Token (first 50 chars): ${ACCESS_TOKEN:0:50}..."
echo ""

# Step 2: Test with CloudHub API
echo "Step 2: Testing CloudHub API..."
echo "Enter your Organization ID:"
read ORG_ID
echo "Enter your Environment ID:"
read ENV_ID

echo ""
echo "Calling GET /cloudhub/api/v2/applications..."
API_RESPONSE=$(curl -s -w "\nHTTP_STATUS:%{http_code}" \
  -X GET "https://anypoint.mulesoft.com/cloudhub/api/v2/applications?retrieveStatistics=true&period=30d" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "X-ANYPNT-ORG-ID: $ORG_ID" \
  -H "X-ANYPNT-ENV-ID: $ENV_ID")

# Extract HTTP status
HTTP_STATUS=$(echo "$API_RESPONSE" | grep "HTTP_STATUS" | cut -d: -f2)
RESPONSE_BODY=$(echo "$API_RESPONSE" | sed '/HTTP_STATUS/d')

echo ""
echo "HTTP Status: $HTTP_STATUS"
echo ""
echo "Response Body:"
echo "$RESPONSE_BODY" | jq . 2>/dev/null || echo "$RESPONSE_BODY"
echo ""

if [ "$HTTP_STATUS" == "200" ]; then
  echo "✅ SUCCESS! Token is valid and authorized."
elif [ "$HTTP_STATUS" == "403" ]; then
  echo "❌ 403 FORBIDDEN - Token is valid but not authorized for this org/env"
  echo ""
  echo "Possible issues:"
  echo "  1. Connected App doesn't have CloudHub permissions"
  echo "  2. Wrong Organization ID or Environment ID"
  echo "  3. Connected App not authorized for this environment"
elif [ "$HTTP_STATUS" == "401" ]; then
  echo "❌ 401 UNAUTHORIZED - Token is invalid or expired"
else
  echo "❌ ERROR: HTTP Status $HTTP_STATUS"
fi

