# Implementation Summary

## Project: Anypoint Apps Monitor

### ✅ Successfully Created and Built

**Location**: `/Users/rmorillo/AnypointCodeBuilder/MyProjects/anypoint-apps-monitor`

---

## What Was Implemented

### 1. **HTTP Endpoint**
- **Path**: `GET /apps`
- **Port**: 8081 (configurable)
- **Query Parameters**:
  - `orgId` - Anypoint Platform Organization ID
  - `environmentName` - Environment ID (note: this is the Environment ID, not the display name)

### 2. **Anypoint Platform API Integration**
The flow integrates with the CloudHub API v2:
- **API Endpoint**: `https://anypoint.mulesoft.com/cloudhub/api/v2/applications`
- **Authentication**: Bearer Token
- **Headers Sent**:
  - `Authorization: Bearer {token}`
  - `X-ANYPNT-ORG-ID: {organizationId}`
  - `X-ANYPNT-ENV-ID: {environmentId}`
- **Query Parameters**:
  - `retrieveStatistics=true` - Enables retrieval of application metrics
  - `period=30d` - Retrieves metrics for the last 30 days

### 3. **Data Retrieved Per Application**
The following information is extracted and returned for each application:

#### Application-Level Data:
- **applicationName**: The domain name of the application
- **runtimeVersion**: Mule runtime version
- **totalVcores**: Total vCores allocated (workers × vCores per worker)
- **workerCount**: Number of workers
- **vcoresPerWorker**: vCores allocated per worker

#### Worker-Level Metrics (for each worker):
- **workerNumber**: Sequential worker number (1, 2, 3, etc.)
- **CPU Metrics**:
  - `maxUsage`: Maximum CPU usage over 30 days
  - `lowUsage`: Minimum CPU usage over 30 days
  - `avgUsage`: Average CPU usage over 30 days
- **Memory Metrics**:
  - `avgMemoryUsedMB`: Average memory used in MB
  - `totalMemoryMB`: Total memory allocated in MB
  - `lowestPercentMemoryUsed`: Lowest memory percentage used
  - `maxPercentMemoryUsed`: Maximum memory percentage used
  - `avgPercentMemory`: Average memory percentage used

### 4. **Response Format**
The API returns data in JSON format with the following structure:

```json
[
  {
    "applicationName": "my-application",
    "runtimeVersion": "4.4.0",
    "totalVcores": 0.2,
    "workerCount": 1,
    "vcoresPerWorker": 0.2,
    "workers": [
      {
        "workerNumber": 1,
        "metrics": {
          "cpu": {
            "maxUsage": 75.5,
            "lowUsage": 10.2,
            "avgUsage": 35.7
          },
          "memory": {
            "avgMemoryUsedMB": 512,
            "totalMemoryMB": 1024,
            "lowestPercentMemoryUsed": 30.5,
            "maxPercentMemoryUsed": 85.2,
            "avgPercentMemory": 50.0
          }
        }
      }
    ]
  }
]
```

---

## Project Structure

```
anypoint-apps-monitor/
├── pom.xml                                    # Maven dependencies and build config
├── mule-artifact.json                         # Mule artifact descriptor
├── src/
│   ├── main/
│   │   ├── mule/
│   │   │   ├── global.xml                    # HTTP configurations
│   │   │   └── anypoint-apps-monitor.xml     # Main flow implementation
│   │   └── resources/
│   │       ├── config.properties             # Configuration properties
│   │       └── log4j2.xml                    # Logging configuration
│   └── test/
│       └── resources/
│           └── log4j2-test.xml               # Test logging configuration
├── README.md                                  # Comprehensive documentation
└── IMPLEMENTATION_SUMMARY.md                  # This file
```

---

## Configuration Required

Before running the application, update the following in `config.properties`:

```properties
# Anypoint Platform Authentication
anypoint.bearer.token=YOUR_ACCESS_TOKEN
```

### How to Get Bearer Token

#### Option 1: Using Connected App (Recommended for Production)
1. Create a Connected App in Anypoint Platform
2. Use OAuth 2.0 to obtain a token

#### Option 2: Using Username/Password (For Testing)
```bash
curl -X POST https://anypoint.mulesoft.com/accounts/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "your-username",
    "password": "your-password"
  }'
```

Extract the `access_token` from the response.

---

## How to Run

### Local Development

1. **Build the project**:
   ```bash
   cd /Users/rmorillo/AnypointCodeBuilder/MyProjects/anypoint-apps-monitor
   mvn clean package
   ```

2. **Run locally**:
   ```bash
   mvn mule:run
   ```

3. **Test the endpoint**:
   ```bash
   curl -X GET "http://localhost:8081/apps?orgId=YOUR_ORG_ID&environmentName=YOUR_ENV_ID"
   ```

### Deploy to CloudHub

You can deploy this application to CloudHub using:
- Anypoint Studio
- Anypoint Code Builder
- Maven with CloudHub plugin
- Runtime Manager UI

---

## Key Features Implemented

✅ HTTP REST endpoint  
✅ Anypoint Platform API integration  
✅ Bearer token authentication  
✅ 30-day metrics retrieval  
✅ CPU and memory metrics per worker  
✅ JSON response formatting  
✅ Error handling with descriptive messages  
✅ Configurable via properties file  
✅ Production-ready structure  

---

## Technical Details

### Dependencies Added
- **mule-http-connector** (v1.7.3) - HTTP listener and request operations
- **mule-sockets-connector** (v1.2.3) - Socket operations support
- **mule-apikit-module** (v1.8.2) - API Kit for REST operations

### Runtime Version
- **Mule Runtime**: 4.10.0
- **JDK**: Java 17

---

## DataWeave Transformation

The application uses DataWeave 2.0 to transform the Anypoint Platform API response into the required format. The transformation:

1. Maps each application from the API response
2. Calculates total vCores (workers × vCores per worker)
3. Creates worker entries for each worker instance
4. Extracts CPU and memory statistics from the API response
5. Formats the data into the required JSON structure

---

## Error Handling

The flow includes error handling that:
- Catches any errors during API calls
- Returns a structured error response in JSON format
- Includes error description and detailed information
- Returns appropriate HTTP status codes

**Error Response Format**:
```json
{
  "error": true,
  "message": "Error description",
  "details": "Detailed error information"
}
```

---

## Testing Recommendations

1. **Test with valid credentials**: Ensure your bearer token is valid
2. **Test with different organizations and environments**: Verify the endpoint works across different contexts
3. **Test error scenarios**: Try invalid orgId, environmentName, or expired tokens
4. **Monitor performance**: Check response times for environments with many applications
5. **Validate metrics**: Compare metrics with what's shown in Runtime Manager

---

## Next Steps

1. ✅ Project created and built successfully
2. 🔧 Configure your bearer token in `config.properties`
3. 🚀 Run the application locally or deploy to CloudHub
4. 🧪 Test the endpoint with your Anypoint Platform credentials
5. 📊 Monitor the application logs for any issues

---

## Support & Documentation

- **Full Documentation**: See `README.md` in the project root
- **Anypoint Platform APIs**: [CloudHub API Documentation](https://anypoint.mulesoft.com/exchange/portals/anypoint-platform/f1e97bc6-315a-4490-82a7-23abe036327a.anypoint-platform/cloudhub-api/)
- **MuleSoft Documentation**: [docs.mulesoft.com](https://docs.mulesoft.com/)

---

## Build Information

✅ **Build Status**: SUCCESS  
📦 **Artifact**: `anypoint-apps-monitor-1.0.0-mule-application.jar`  
📍 **Location**: `target/anypoint-apps-monitor-1.0.0-mule-application.jar`

---

**Created**: October 19, 2025  
**Mule Runtime**: 4.10.0  
**Project Type**: Mule Application

