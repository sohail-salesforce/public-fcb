# Anypoint Apps Monitor

A MuleSoft application that retrieves running applications from the Anypoint Platform with detailed metrics including CPU and memory usage over the last 30 days.

## Overview

This application exposes an HTTP endpoint that accepts an Organization ID and Environment name as query parameters, then retrieves all running applications in that environment along with their metrics using the Anypoint Platform APIs.

## Features

- HTTP REST endpoint to retrieve application information
- Integration with Anypoint Platform CloudHub API v2
- Retrieves comprehensive application metrics:
  - Application name
  - Runtime version
  - Total vCores
  - Worker count
  - vCores per worker
  - CPU metrics (max, min, avg) over last 30 days
  - Memory metrics (avg used, total, lowest %, max %, avg %) over last 30 days
- Returns data in JSON format
- Error handling with descriptive error messages

## Prerequisites

- MuleSoft Anypoint Studio or Anypoint Code Builder
- Java 17
- Maven 3.x
- Anypoint Platform account with API access
- Valid Anypoint Platform credentials (Bearer Token or Client ID/Secret)

## Configuration

### 1. Update config.properties

Navigate to `src/main/resources/config.properties` and update the following properties:

```properties
# HTTP Listener Configuration
http.port=8081
http.host=0.0.0.0

# Anypoint Platform API Configuration
anypoint.platform.base.url=https://anypoint.mulesoft.com
anypoint.cloudhub.api.url=https://anypoint.mulesoft.com/cloudhub/api/v2

# Anypoint Platform Authentication
# Replace with your actual credentials or use secure properties
anypoint.client.id=YOUR_CLIENT_ID
anypoint.client.secret=YOUR_CLIENT_SECRET
anypoint.bearer.token=YOUR_ACCESS_TOKEN
```

### 2. Get Anypoint Platform Access Token

You can obtain a bearer token by:

1. **Using Connected App (Recommended for Production)**:
   - Create a Connected App in Anypoint Platform
   - Use the Client ID and Client Secret to obtain a token via OAuth 2.0

2. **Using Username/Password (For Testing)**:
   ```bash
   curl -X POST https://anypoint.mulesoft.com/accounts/login \
     -H "Content-Type: application/json" \
     -d '{
       "username": "your-username",
       "password": "your-password"
     }'
   ```
   
   Extract the `access_token` from the response and use it as the bearer token.

### 3. Get Organization ID and Environment ID

To find your Organization ID:
1. Log in to Anypoint Platform
2. Navigate to Access Management > Organization
3. Copy the Organization ID from the URL or organization details

To find your Environment ID:
1. Navigate to the desired environment
2. Copy the Environment ID from the URL or environment settings

## Build and Run

### Build the project:
```bash
cd /Users/rmorillo/AnypointCodeBuilder/MyProjects/anypoint-apps-monitor
mvn clean package
```

### Run locally:
```bash
mvn mule:run
```

Or deploy to CloudHub using Anypoint Studio or Maven.

## API Usage

### Endpoint

```
GET http://localhost:8081/apps?orgId={ORGANIZATION_ID}&environmentName={ENVIRONMENT_ID}
```

### Query Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| orgId | String | Yes | The Anypoint Platform Organization ID |
| environmentName | String | Yes | The Environment ID (not the environment name) |

### Example Request

```bash
curl -X GET "http://localhost:8081/apps?orgId=your-org-id&environmentName=your-env-id"
```

### Example Response

```json
[
  {
    "applicationName": "my-app",
    "runtimeVersion": "4.4.0",
    "totalVcores": 0.2,
    "workerCount": 1,
    "vcoresPerWorker": 0.2,
    "workers": [
      {
        "workerNumber": 1,
        "metrics": {
          "cpu": {
            "maxUsage": 75.5,
            "lowUsage": 10.2,
            "avgUsage": 35.7
          },
          "memory": {
            "avgMemoryUsedMB": 512,
            "totalMemoryMB": 1024,
            "lowestPercentMemoryUsed": 30.5,
            "maxPercentMemoryUsed": 85.2,
            "avgPercentMemory": 50.0
          }
        }
      }
    ]
  }
]
```

### Error Response

```json
{
  "error": true,
  "message": "An error occurred while fetching applications",
  "details": "Detailed error description"
}
```

## Project Structure

```
anypoint-apps-monitor/
├── pom.xml                           # Maven project configuration
├── mule-artifact.json                # Mule artifact descriptor
├── src/
│   ├── main/
│   │   ├── mule/
│   │   │   ├── global.xml           # Global configurations
│   │   │   └── anypoint-apps-monitor.xml  # Main flow
│   │   └── resources/
│   │       ├── config.properties     # Configuration properties
│   │       └── log4j2.xml           # Logging configuration
│   └── test/
│       └── resources/
│           └── log4j2-test.xml      # Test logging configuration
└── README.md                         # This file
```

## Flow Description

### get-apps-flow

1. **HTTP Listener**: Listens for GET requests on `/apps`
2. **Set Variables**: Extracts `orgId` and `environmentName` from query parameters
3. **HTTP Request**: Calls Anypoint Platform CloudHub API v2 to retrieve applications
   - Endpoint: `/cloudhub/api/v2/applications`
   - Headers: Authorization (Bearer token), X-ANYPNT-ORG-ID, X-ANYPNT-ENV-ID
   - Query Parameters: `retrieveStatistics=true`, `period=30d`
4. **DataWeave Transform**: Processes the response and transforms it into the required JSON structure
5. **Error Handler**: Catches and formats errors into a readable JSON response

## Anypoint Platform API Details

This application uses the CloudHub API v2:
- **Base URL**: `https://anypoint.mulesoft.com`
- **API Path**: `/cloudhub/api/v2/applications`
- **Authentication**: Bearer Token
- **Required Headers**:
  - `Authorization: Bearer {token}`
  - `X-ANYPNT-ORG-ID: {organizationId}`
  - `X-ANYPNT-ENV-ID: {environmentId}`

## Security Considerations

⚠️ **Important**: Never commit actual credentials to version control!

For production deployments:
1. Use secure properties or external credential management
2. Store credentials in CloudHub secure properties
3. Use Runtime Manager secure properties for on-premises deployments
4. Consider using MuleSoft Secure Configuration Properties module

## Troubleshooting

### Common Issues

1. **Authentication Error (401)**
   - Verify your bearer token is valid and not expired
   - Check that the token has proper permissions

2. **Not Found Error (404)**
   - Verify the Organization ID and Environment ID are correct
   - Ensure the environment exists and is accessible

3. **No Data Returned**
   - Check that applications exist in the specified environment
   - Verify applications are in "RUNNING" status

4. **Connection Timeout**
   - Check network connectivity to anypoint.mulesoft.com
   - Verify firewall rules allow HTTPS outbound traffic

## Additional Resources

- [Anypoint Platform APIs Documentation](https://anypoint.mulesoft.com/exchange/portals/anypoint-platform/)
- [CloudHub API v2 Reference](https://anypoint.mulesoft.com/exchange/portals/anypoint-platform/f1e97bc6-315a-4490-82a7-23abe036327a.anypoint-platform/cloudhub-api/)
- [MuleSoft Documentation](https://docs.mulesoft.com/)

## License

This project is provided as-is for educational and demonstration purposes.

## Author

Created for Anypoint Platform integration with CloudHub API v2

